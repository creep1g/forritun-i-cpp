from my_cpp_module import *

print(get_number_from_cpp())
print(get_string_from_cpp())
print(add_two_cpp_doubles(12.1, 13.3))
print(get_list_from_cpp())
print(get_count_from_number(3, 5))
print(get_count_from_number(275, 13))