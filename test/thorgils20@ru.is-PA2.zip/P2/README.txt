Version: C-ish
Compilation: It should be enough to use 'make' to build the project. If make fails g++ main.cpp src/*.cpp should do the trick.
