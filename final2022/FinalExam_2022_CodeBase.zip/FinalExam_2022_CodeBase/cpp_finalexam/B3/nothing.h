//This is here so Makefile doesn't fail when copying *.h
//You can rename this file or make your own .h files if you need
//Just make sure to update the Makefile to compile your program correctly
