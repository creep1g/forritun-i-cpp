COMPILATION:
	in PA4 directory type make into the terminal
	to run the program type ./Athletics

INFO:
	I could not find a use for the template class.
	Standard library datastructures are used, mostly maps.
	Input check is non-existent in some places do to time constraints.
	Some functionality is not present, such as printing and saving rosters.
	However each athlete, team, coach is saved in csv files.
	The original thought behind the roster was to same each team in a separate file.
