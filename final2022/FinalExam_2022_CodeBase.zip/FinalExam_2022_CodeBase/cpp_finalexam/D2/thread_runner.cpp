#include <iostream>
#include "data_processing.h"

void process_stuff(DataStore &ds, DataProcessing dproc, int my_number){
    std::cout << "Processor #" << my_number << " starting" << std::endl;
    while(!ds.is_empty()){
        DataPart dp = ds.get_next();
        std::cout << "Processor #" << my_number << " processing data: " << dp << std::endl;
        int result = dproc.process(dp);
        std::cout << "Processor #" << my_number << " RESULT: " << result << std::endl;
    }
    std::cout << "Processor #" << my_number << " STOPPING" << std::endl;
}

int main(){
    DataStore ds;
    DataProcessing dproc;

    process_stuff(ds, dproc, 1);

    return 0;
}