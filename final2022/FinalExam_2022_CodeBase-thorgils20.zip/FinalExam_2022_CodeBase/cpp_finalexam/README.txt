Problems I want graded in Part D:

D1 (Network): NO
D2 (Threads): YAAS
D3 (BMPFile): YAAS
D4 (PModule): NO

Other comments and messages:
Lovely Exam!
