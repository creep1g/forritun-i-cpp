Problems I want graded in Part D:

D1 (Network): NO
D2 (Threads): NO
D3 (BMPFile): NO
D4 (PModule): NO

Other comments and messages:
