#ifndef WRITABLELIST_H_224457345
#define WRITABLELIST_H_224457345

#include "labelled_list.h"

#endif //WRITABLELIST_H_224457345