### Huffcode Version A. ###

## Installation and usage:
   1. In PA3-huffcode directory run make
   2. Encoding:
   		./huffcode -e in_file.txt out_file.txt
   3. Decoding:
   		./huffcode -d in_file.txt out_file.txt
   4. Help:
		./huffcode -h

## Comments
Due to covid me and my 2 year old son have been in quarantined which has made working on this hard
this has caused my code to be messy and breaking more design principles than it should.
