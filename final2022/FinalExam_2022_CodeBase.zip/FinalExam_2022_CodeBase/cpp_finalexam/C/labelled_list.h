#ifndef LABELLEDLIST_H_77447345
#define LABELLEDLIST_H_77447345

struct NumericData{
    int id;
    int place;
    double amount;
};

//TODO: Implement LabelledList

#endif //LABELLEDLIST_H_77447345